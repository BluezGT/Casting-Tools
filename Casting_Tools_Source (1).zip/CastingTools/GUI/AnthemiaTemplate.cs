﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BepInEx;
using GorillaNetworking;
using ExitGames.Client.Photon;
using GorillaTag;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using UnityEngine.XR;
using Object = UnityEngine.Object;
using Random = UnityEngine.Random;
using static OVRPlugin;
using System.Reflection;

namespace GuiTemplate
{
    [BepInPlugin("CastingTools", "CastingTools", "1.0.1")]
    public class AnthemiaTemplate : BaseUnityPlugin
    {
        public string GUIName = "Casting Tools V1";
        private Color guiColor = Color.red;
        private float colorTimer = 0f;
        private Rect windowRect = new Rect(10, 10, 250, 250);//Size of GUI
        public string GUIText = "Show Tools";

        private static bool TogThing;
        void Update()//all RGB stuff
        {
            float r = Mathf.Abs(Mathf.Sin(colorTimer * 0.4f));
            float g = Mathf.Abs(Mathf.Sin(colorTimer * 0.5f));
            float b = Mathf.Abs(Mathf.Sin(colorTimer * 0.6f));
            guiColor = new Color(r, g, b);
            colorTimer += Time.deltaTime;
        }
        public void Start()
        {
            ColorUtility.TryParseHtmlString("#ffc1cc", out color1);//uses hex codes
            ColorUtility.TryParseHtmlString("#98FF98", out color2);
        }
        
        public bool youturnnedmeon = false;

        void OnGUI()//Dont really mess with dis
        {
            GUI.backgroundColor = guiColor;
            GUI.color = guiColor;
            if (GUI.Button(new Rect(20, 20, 100, 20), GUIText))
            {
                if (youturnnedmeon == false)
                {
                    GUIText = "Hide Tools";
                    youturnnedmeon = true;
                }
                else
                {
                    GUIText = "Show Tools";
                    youturnnedmeon = false;
                }
            }
            if (youturnnedmeon)
            {
                windowRect = GUI.Window(10000, windowRect, MainGUI, GUIName);//opens GUI
            }
        }
        public int PageNum;
        public Color color1;
        public Color color2;
        public string TextBox = "";
        void MainGUI(int windowID)
        {
            GUI.contentColor = color1;//sets text color
            GUI.backgroundColor = color2;//sets button color
            int PageNumlol = PageNum + 1;//the real page number
            switch (PageNum)
            {
                case 0://Page 1//



                    //Collum 1//
                    TextBox = GUI.TextArea(new Rect(20, 50, 100, 20), TextBox);
                    if (GUI.Button(new Rect(20, 80, 100, 20), "Join"))
                    {
                        PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(TextBox);
                    }
                    if (GUI.Button(new Rect(20, 110, 100, 20), "SetName Weird"))
                    {
                        string PlayerName = TextBox;
                        PhotonNetwork.LocalPlayer.NickName = TextBox;
                        GorillaComputer.instance.currentName = TextBox;
                        GorillaComputer.instance.savedName = TextBox;
                        PlayerPrefs.SetString("GorillaLocomotion.PlayerName", TextBox);
                    }
                    if (GUI.Button(new Rect(20, 140, 100, 20), "Disconnect"))
                    {
                        PhotonNetwork.Disconnect();
                    }
                    if (GUI.Button(new Rect(20, 170, 100, 20), "In room: null"))
                    {
                        if (PhotonNetwork.CurrentRoom != null && !PhotonNetwork.CurrentRoom.IsVisible)
                        {
                            
                        }
                        else
                        {
                            
                        }
                    }
                    



                    



                    break;









                    











            }
            GUI.DragWindow();
        }
        private bool isMenuOpen = true;

        private GameObject betterDayNight;

        private readonly float minValue = 1000f;

        private readonly float maxValue = 10000f;

        public static bool ShowHide;

        private float sliderValue = 10000f;

        private bool optionCityOn = false;

        private bool optionForestOn = true;

        private bool optionCanyonsOn = false;

        private bool optionMountainsOn = false;

        private bool optionBeachOn = false;

        private bool optionCloudsOn = false;

        private bool optionLeavesOn = false;

        private GameObject city = null;

        private GameObject forest = null;

        private GameObject canyons = null;

        private GameObject mountains = null;

        private GameObject beach = null;

        private GameObject clouds = null;

        private Transform smallTreesParent;

        private GameObject treeLeaf;

        private GameObject treeLeaf1;

        private GameObject treeLeaf2;

        private GameObject treeLeaf3;

        private GameObject smallTreesParentObject;

    }
}
